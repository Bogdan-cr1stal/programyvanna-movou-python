sum_hits = 0

for hour in range(16):
    sum_hits += hour

print("Кількість ударів годинника від 00 до 15 год становить", sum_hits)
