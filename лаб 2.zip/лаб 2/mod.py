def amebas(n):
    num = n // 3
    return 2 ** num
