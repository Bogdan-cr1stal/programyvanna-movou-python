from mod import amebas

n = int(input("Введіть кількість годин n = "))
print("Через", n, "годин буде", amebas(n), "амеб")